This is an very easy demo for fresh-hand to get an overview about the ElasticSearch integrate the Springboot.
This code is reference to this online course of this site:https://www.imooc.com/learn/889.
If you are interested in it,you can access to it.