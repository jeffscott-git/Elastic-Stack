package com.elasticsearch;

import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.elasticsearch.transport.client.PreBuiltTransportClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * 1.配置elasticsearch服务器和端口
 * 2.创建client对象和elasticsearch进行交互
 */
@Configuration
public class MyConfig {
    @Bean
    public TransportClient client() throws UnknownHostException {
        InetSocketTransportAddress  node =new InetSocketTransportAddress(
                InetAddress.getByName("192.168.108.117"),9300
        );
        Settings settings = Settings.builder()
                .put("cluster.name","cluster1")
                .build();
        TransportClient client = new PreBuiltTransportClient(settings);
        client.addTransportAddress(node);
        return  client;
    }
}
