package com.elasticsearch;

import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.action.update.UpdateResponse;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.common.xcontent.XContentFactory;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/***
 * 代码参考：https://www.imooc.com/learn/889
 */
@SpringBootApplication
@EntityScan(value = "com.elasticsearch.entity")
@RestController
public class FirstAppApplication {
	@Autowired
	private TransportClient client;

	/**
	 * 1.匹配根路径
	 * @return
	 */
	@GetMapping("/")
	public String index(){return  "index";}

	/***
	 * 1.实现查找功能
	 * 2.GetMapping为通过注解的方式，进行url路由
	 * @param id
	 * @return
	 */
	@GetMapping("/get/bank/account")
	public ResponseEntity get(@RequestParam(name = "id",defaultValue = "god bless you!")String id){
    	if (id.isEmpty()){
			return  new ResponseEntity(HttpStatus.NOT_FOUND);
		}
    	GetResponse result = this.client.prepareGet("bank","account",id)
				.get();
    	if(!result.isExists()){
    		return  new ResponseEntity(HttpStatus.NOT_FOUND);
		}
    	return  new ResponseEntity(result.getSource(), HttpStatus.OK);
	}

	/***
	 * 1.实现增加数据的功能
	 * 2.使用XContentFactory.jsonBuilder构建json对象
	 * @param account_number
	 * @param firstname
	 * @param address
	 * @param balance
	 * @param gender
	 * @param city
	 * @param employer
	 * @param state
	 * @param age
	 * @param email
	 * @param lastname
	 * @return
	 */
	@PostMapping("add/bank/account")
	@ResponseBody
	public ResponseEntity add(
			@RequestParam(name = "account_number") int account_number,
			@RequestParam(name = "firstname") String firstname,
			@RequestParam(name = "address") String address,
			@RequestParam(name = "balance") int balance,
			@RequestParam(name = "gender") String gender,
			@RequestParam(name = "city") String city,
			@RequestParam(name = "employer") String employer,
			@RequestParam(name = "state") String state,
			@RequestParam(name = "age") int age,
			@RequestParam(name = "email") String email,
			@RequestParam(name = "lastname") String lastname
	){
    	try{
			XContentBuilder content = XContentFactory.jsonBuilder()
					.startObject()
					.field("account_number",account_number)
					.field("firstname",firstname)
					.field("address",address)
					.field("balance",balance)
					.field("gender",gender)
					.field("gender",city)
					.field("employer",employer)
					.field("state",state)
					.field("age",age)
					.field("email",email)
					.field("lastname",lastname)
					.endObject();
			IndexResponse result = this.client.prepareIndex("bank","account")
					.setSource(content)
					.get();
			return  new ResponseEntity(result.getId(),HttpStatus.OK);
		}catch (IOException e){
    		e.printStackTrace();
    		return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/***
	 * 1.删除数据
	 * @param id
	 * @return
	 */
	@DeleteMapping("delete/bank/account")
	@ResponseBody
	public ResponseEntity delete(@RequestParam(name = "id") String id){
		DeleteResponse result = this.client.prepareDelete("bank","account",id)
				.get();
		return  new ResponseEntity(result.getResult().toString(),HttpStatus.OK);
	}

	/**
	 * 1.更新数据
	 * @param id
	 * @param address
	 * @param employer
	 * @return
	 */
	@PutMapping("update/bank/account")
	@ResponseBody
	public ResponseEntity update(
			@RequestParam(name = "id") String id,
			@RequestParam(name = "address",required = false)String address,
			@RequestParam(name = "employer",required = false)String employer
	){
		UpdateRequest update = new UpdateRequest("bank","account",id);
		try {
			XContentBuilder builder = XContentFactory.jsonBuilder()
					.startObject();
			if (address!=null){
				builder.field("address",address);
			}
			if (employer!=null){
				builder.field("employer",employer);
			}
			builder.endObject();
			update.doc(builder);
		}catch (IOException e){
			return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		try {
			UpdateResponse result = this.client.update(update).get();
			return new ResponseEntity(result.getResult().toString(),HttpStatus.OK);
		}catch (Exception e){
			e.printStackTrace();
			return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/***
	 * 1.使用bool查询和过滤器进行高级查询，具体原理请参考官方文档。
	 * @param gender
	 * @param city
	 * @param gtBalanceCount
	 * @param ltBalanceCount
	 * @return
	 */
	@PostMapping("query/bank/account")
	@ResponseBody
	public ResponseEntity query(
			@RequestParam(name = "gender",required = false)String gender,
			@RequestParam(name = "city",required = false)String city,
			@RequestParam(name = "gt_balance_count",defaultValue = "0")int gtBalanceCount,
			@RequestParam(name = "lt_balance_count",required = false) Integer ltBalanceCount
	){
		BoolQueryBuilder boolQuery = QueryBuilders.boolQuery();
		if(gender!=null){
			boolQuery.must(QueryBuilders.matchQuery("gender",gender));
		}
		if(city!=null){
			boolQuery.must(QueryBuilders.matchQuery("city",city));
		}
		RangeQueryBuilder rangeQuery = QueryBuilders.rangeQuery("balance_count")
				.from(gtBalanceCount);
		if (ltBalanceCount!=null&&ltBalanceCount>0){
			rangeQuery.to(ltBalanceCount);
		}
		boolQuery.filter(rangeQuery);

		SearchRequestBuilder builder = this.client.prepareSearch("bank")
				.setTypes("account")
				.setSearchType(SearchType.DFS_QUERY_THEN_FETCH)
				.setQuery(boolQuery)
				.setFrom(0)
				.setSize(10);
		System.out.println(builder);

		SearchResponse response = builder.get();
		List<Map<String,Object>> result = new ArrayList<Map<String, Object>>();
		for (SearchHit hit:response.getHits()){
			result.add(hit.getSource());
		}
		System.out.println(result);
		return new ResponseEntity(result,HttpStatus.OK);
	}

	/**
	 * 1.主类
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(FirstAppApplication.class, args);
	}
}
